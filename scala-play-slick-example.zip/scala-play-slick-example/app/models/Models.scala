package models

case class Product(name: String, description: String, price: Int)
