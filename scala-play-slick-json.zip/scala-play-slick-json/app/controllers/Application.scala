package controllers

import javax.inject.Inject

import daos.{ProductsDAO, CategoriesDAO, UsersDAO, PurchasesDAO}
import models.{Products, ProductsREST, Categories, CategoriesREST, Users, UsersREST, Purchases, PurchasesREST}
import play.api.libs.json.Json
import play.api.libs.json._
import play.api.mvc._
import play.api.libs.concurrent.Execution.Implicits.defaultContext

class Application @Inject() (productsDAO: ProductsDAO, categoriesDAO:CategoriesDAO, usersDAO:UsersDAO, purchasesDAO:PurchasesDAO) extends Controller {

    def index = Action.async { implicit  request =>
         {productsDAO.all} map {
        (products) => Ok(Json.toJson(products.toString()))
      //      products => Ok("produktow: "+products.length.toString())
    }
  }

  def getcategories = Action.async { implicit  request =>
    {categoriesDAO.all} map {
      (categories) => Ok(Json.toJson(categories.toString()))
    }
  }

  def getusers = Action.async { implicit  request =>
    {usersDAO.all} map {
      (users) => Ok(Json.toJson(users.toString()))
    }
  }

  def getpurchases = Action.async { implicit  request =>
    {purchasesDAO.all} map {
      (purchases) => Ok(Json.toJson(purchases.toString()))
    }
  }


  // products
  def createproduct = Action { implicit request =>
    var json:ProductsREST = request.body.asJson.get.as[ProductsREST]
    productsDAO.insert(new Products(1L, json.tytul, json.opis, json.catId))
    Redirect(routes.Application.index())
    Ok("product created")
      }

  def getproduct(id:Long) = Action.async { implicit request =>
    val computerAndOptions = for {
      product <- productsDAO.findById(id)
    } yield (product)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(products) => Ok(Json.toJson(new ProductsREST(products.tytul, products.opis, products.catId)))
        case None => NotFound("nie znaleziono")
      }
    }
  }

  def updateProduct(id:Long) = Action.async { implicit request =>
    var json:ProductsREST = request.body.asJson.get.as[ProductsREST]

    val computerAndOptions = for {
      product <- productsDAO.findById(id)
    } yield (product)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(products) => {productsDAO.update(id, new Products(id, json.tytul, json.opis, json.catId)); Ok("Updated")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

  def deleteproduct(id:Long) = Action.async{ implicit request =>
    //productsDAO.delete(id)
    //Ok("Deleted")
    val computerAndOptions = for {
      product <- productsDAO.findById(id)
    } yield (product)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(products) => {productsDAO.delete(id); Ok("Deleted")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

  //categories
  def createcategory = Action { implicit request =>
    var json:CategoriesREST = request.body.asJson.get.as[CategoriesREST]
    categoriesDAO.insert(new Categories(1L, json.tytul))
    Ok("Created")
  }
  def getcategory(id:Long) = Action.async { implicit request =>
    val computerAndOptions = for {
      category <- categoriesDAO.findById(id)
    } yield (category)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(categories) => Ok(Json.toJson(new CategoriesREST(categories.tytul)))
        case None => NotFound("nie znaleziono")
      }
    }
  }

  def updateCategory(id:Long) = Action.async { implicit request =>
    var json:CategoriesREST = request.body.asJson.get.as[CategoriesREST]

    val computerAndOptions = for {
      category <- categoriesDAO.findById(id)
    } yield (category)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(categories) => {categoriesDAO.update(id, new Categories(id, json.tytul)); Ok("Updated")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

  def deletecategory(id:Long) = Action.async { implicit request =>
    //categoriesDAO.delete(id)
    //Ok("Deleted")
    val computerAndOptions = for {
      category <- categoriesDAO.findById(id)
    } yield (category)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(categories) => {categoriesDAO.delete(id); Ok("Deleted")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }
// users
  def createuser = Action { implicit request =>
    var json:UsersREST = request.body.asJson.get.as[UsersREST]
    usersDAO.insert(new Users(1L, json.username))
    Ok("Created")
  }
  def getuser(id:Long) = Action.async { implicit request =>
    val computerAndOptions = for {
      user <- usersDAO.findById(id)
    } yield (user)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(users) => Ok(Json.toJson(new UsersREST(users.username)))
        case None => NotFound("nie znaleziono")
      }
    }
  }

  def updateUser(id:Long) = Action.async { implicit request =>
    var json:UsersREST = request.body.asJson.get.as[UsersREST]

    val computerAndOptions = for {
      user <- usersDAO.findById(id)
    } yield (user)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(users) => {categoriesDAO.update(id, new Categories(id, json.username)); Ok("Updated")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

  def deleteuser(id:Long) = Action.async { implicit request =>
    //usersDAO.delete(id)
    //Ok("Deleted")
    val computerAndOptions = for {
      user <- usersDAO.findById(id)
    } yield (user)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(users) => {usersDAO.delete(id); Ok("Deleted")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

//purchases
  def createpurchase = Action { implicit request =>
    var json:PurchasesREST = request.body.asJson.get.as[PurchasesREST]
    purchasesDAO.insert(new Purchases(1L, json.prodId, json.userId))
    Ok("Created")
  }
  def getpurchase(id:Long) = Action.async { implicit request =>
    val computerAndOptions = for {
      purchase <- purchasesDAO.findById(id)
    } yield (purchase)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(purchases) => Ok(Json.toJson(new PurchasesREST(purchases.prodId,purchases.userId)))
        case None => NotFound("nie znaleziono")
      }
    }
  }

  def updatePurchase(id:Long) = Action.async { implicit request =>
    var json:PurchasesREST = request.body.asJson.get.as[PurchasesREST]

    val computerAndOptions = for {
      purchase <- purchasesDAO.findById(id)
    } yield (purchase)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(purchases) => {purchasesDAO.update(id, new Purchases(id, json.prodId, json.userId)); Ok("Updated")}
        case None => NotFound("Nie znaleziono")
      }
    }
  }

  def deletepurchase(id:Long) = Action.async { implicit request =>
    //purchasesDAO.delete(id)
    //Ok("Deleted")
    val computerAndOptions = for {
      purchase <- purchasesDAO.findById(id)
    } yield (purchase)

    computerAndOptions.map { case (computer) =>
      computer match {
        case Some(purchases) => {purchasesDAO.delete(id); Ok("Deleted")}
        case None => NotFound("Nie znaleziono")
      }
    }

  }



}