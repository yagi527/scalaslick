package daos

import javax.inject.Inject
import scala.concurrent.Future
import models.{Categories}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile
import play.api.libs.concurrent.Execution.Implicits.defaultContext

/**
  * Created by kprzystalski on 23/04/17.
  */

class CategoriesDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Categories = TableQuery[CategoriesTable]

  def all(): Future[Seq[Categories]] = db.run(Categories.result)

  def insert(category: Categories): Future[Unit] = db.run(Categories += category).map { _ => () }

  def findById(id: Long): Future[Option[Categories]] = db.run(Categories.filter(_.catId === id).result.headOption)

  def update(id: Long, category: Categories): Future[Unit] = {
    val categoryToUpdate: Categories = category.copy(id)
    db.run(Categories.filter(_.catId === id).update(categoryToUpdate)).map(_ => ())
  }

  def delete(id: Long): Future[Unit] = db.run(Categories.filter(_.catId === id).delete).map(_ => ())


  class CategoriesTable(tag: Tag) extends Table[Categories](tag, "Categories") {
    def catId = column[Long]("catId",O.AutoInc, O.AutoInc)
    def tytul = column[String]("tytul")
    def * = (catId, tytul) <> (models.Categories.tupled, models.Categories.unapply)
  }

}
