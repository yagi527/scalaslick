package daos

import javax.inject.Inject
import scala.concurrent.Future
import models.{Purchases, PurchasesREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile
import play.api.libs.concurrent.Execution.Implicits.defaultContext

import scala.concurrent.{ExecutionContext, Future}

/**
  * Created by kprzystalski on 23/04/17.
  */

class PurchasesDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Purchases = TableQuery[PurchasesTable]

  def all(): Future[Seq[Purchases]] = db.run(Purchases.result)

  def insert(purchase: Purchases): Future[Unit] = db.run(Purchases += purchase).map { _ => () }

  def findById(id: Long): Future[Option[Purchases]] = db.run(Purchases.filter(_.purId === id).result.headOption)

  def update(id: Long, purchase: Purchases): Future[Unit] = {
    val purchaseToUpdate: Purchases = purchase.copy(id)
    db.run(Purchases.filter(_.purId === id).update(purchaseToUpdate)).map(_ => ())
  }

  def delete(id: Long): Future[Unit] = db.run(Purchases.filter(_.purId === id).delete).map(_ => ())


  class PurchasesTable(tag: Tag) extends Table[Purchases](tag, "Purchases") {
    def purId = column[Long]("purId",O.AutoInc, O.AutoInc)
    def prodId = column[Long]("prodId")
    def userId = column[Long]("userId")
    def * = (purId, prodId,userId) <> (models.Purchases.tupled, models.Purchases.unapply)
  }

}
