package daos

import javax.inject.Inject

import scala.concurrent.Future
import models.{Products,Categories}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile
import play.api.libs.concurrent.Execution.Implicits.defaultContext

/**
  * Created by kprzystalski on 23/04/17.
  */

class ProductsDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._
  import play.api.libs.json.Json
  import play.api.libs.json._

  val products = TableQuery[ProductsTable]

  def all(): Future[Seq[Products]] = db.run(products.result)

  def insert(product: Products): Future[Unit] = db.run(products += product).map { _ => () }

  def findById(id: Long): Future[Option[Products]] = db.run(products.filter(_.prodId === id).result.headOption)

  def update(id: Long, product: Products): Future[Unit] = {
    val productToUpdate: Products = product.copy(id)
    db.run(products.filter(_.prodId === id).update(productToUpdate)).map(_ => ())
  }

  def delete(id: Long): Future[Unit] = db.run(products.filter(_.prodId === id).delete).map(_ => ())

  class ProductsTable(tag: Tag) extends Table[Products](tag, "Products") {
    def prodId = column[Long]("prodId",O.AutoInc, O.AutoInc)
    def tytul = column[String]("tytul")
    def opis = column[String]("opis")
    def catId = column[Long]("catId")
    def * = (prodId, tytul, opis, catId) <> (models.Products.tupled, models.Products.unapply)
  }

}
