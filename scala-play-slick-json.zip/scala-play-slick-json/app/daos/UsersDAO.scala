package daos

import javax.inject.Inject
import scala.concurrent.Future
import models.{Users, UsersREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile
import play.api.libs.concurrent.Execution.Implicits.defaultContext


import scala.concurrent.{ExecutionContext, Future}

/**
  * Created by kprzystalski on 23/04/17.
  */

class UsersDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Users = TableQuery[UsersTable]

  def all(): Future[Seq[Users]] = db.run(Users.result)

  def insert(user: Users): Future[Unit] = db.run(Users += user).map { _ => () }

  def findById(id: Long): Future[Option[Users]] = db.run(Users.filter(_.userId === id).result.headOption)

  def update(id: Long, user: Users): Future[Unit] = {
    val userToUpdate: Users = user.copy(id)
    db.run(Users.filter(_.userId === id).update(userToUpdate)).map(_ => ())
  }

  def delete(id: Long): Future[Unit] = db.run(Users.filter(_.userId === id).delete).map(_ => ())

  class UsersTable(tag: Tag) extends Table[Users](tag, "Users") {
    def userId = column[Long]("userId",O.AutoInc, O.AutoInc)
    def username = column[String]("username")
    def * = (userId, username) <> (models.Users.tupled, models.Users.unapply)
  }

}
