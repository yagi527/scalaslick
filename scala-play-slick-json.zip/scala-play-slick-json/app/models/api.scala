package models

import play.api.libs.json.Json

/**
  * Created by kprzystalski on 23/04/17.
  */
case class ProductsREST(tytul: String, opis: String, catId: Long)

object ProductsREST {
  implicit val productsFormat = Json.format[ProductsREST]
}

case class CategoriesREST(tytul: String)

object CategoriesREST {
  implicit val categoriesFormat = Json.format[CategoriesREST]
}

case class UsersREST(username: String)

object UsersREST {
  implicit val usersFormat = Json.format[UsersREST]
}

case class PurchasesREST(prodId:Long, userId:Long)

object PurchasesREST {
  implicit val purchasesFormat = Json.format[PurchasesREST]
}


